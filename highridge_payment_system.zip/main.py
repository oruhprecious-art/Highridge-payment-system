# main.py
import random

workers=[]
for i in range(1,401):
    workers.append({"name":f"Worker_{i}","salary":random.randint(5000,30000),"gender":random.choice(["male","female"])})

for w in workers:
    try:
        level=""
        if 10000 < w['salary'] < 20000:
            level="A1"
        if 7500 < w['salary'] < 30000 and w['gender']=="female":
            level="A5-F"
        print(w['name'], w['salary'], w['gender'], level)
    except Exception as e:
        print('Error:', e)
