# Highridge Payment System

This project includes Python and R scripts for generating payment slips for 400 workers.

## Files
- main.py
- main.R
- README.md

Run Python:
```
python main.py
```
Run R:
```
Rscript main.R
```
