# main.R
set.seed(123)
workers <- data.frame(name=paste0('Worker_',1:400), salary=sample(5000:30000,400,replace=TRUE), gender=sample(c('male','female'),400,replace=TRUE))
for(i in 1:nrow(workers)){
  level <- ''
  tryCatch({
    if(workers$salary[i]>10000 & workers$salary[i]<20000){level<-'A1'}
    if(workers$salary[i]>7500 & workers$salary[i]<30000 & workers$gender[i]=='female'){level<-'A5-F'}
    print(paste(workers$name[i], workers$salary[i], workers$gender[i], level))
  }, error=function(e){print('Error')})
}
